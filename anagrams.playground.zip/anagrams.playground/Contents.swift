import UIKit

var str = "Hello, playground"
func anagrams(){
    let string1 = "keep"
    let characters1 = Array(string1)
    let string2 = "peek"
    let characters2 = Array(string2)
    for i in 0...4-1 {
    if string1 == string2{
        print("are anagrams")
    
}
}
}
    anagrams()
