import UIKit

var str = "Hello, playground"
func temperatu(temperature:Float,char:Character)->Float
{
    var conversion:Float=0.0

    if (char == "f" || char == "F")
    {
        conversion = Float (temperature - 32) * ( 5 / 9)
    }
    else if (char == "c" || char == "C")
    {
        conversion = Float (temperature * ( 9 / 5)) + 32
    }
    return conversion;
    
    
}
var f=temperatu(temperature:27.0,char:"f")
print(f)

