import Foundation
import Swift
func payment1()  {
    let y = 7.0
    var p = 4.2
    var r = 6.0
    var n = 4.0
    let z = 12*y
    var r0 = r/12*100
    var payment = p * r0 / (1 - pow((1 + r0), -n))
    print(payment)
}
payment1()
