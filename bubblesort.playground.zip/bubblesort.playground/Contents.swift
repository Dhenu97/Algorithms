import UIKit

var str = "Hello, playground"
func bubblesort(){
    // in bubblesort first two elements are sorted at the beginning it undergoes 4-5 rounds
    // in each and rounds it will put the hoighest vale at the ending
    var a = [2,34,55,7,66,5,3,14]
    //consider the temprary value = 0
    var temp = 0
    // the loop runs from 0 to 7-1 ie.. 6 times
    for i in 0...7-1{
        //i is considered becz 
        for j in 0...7-1-i{
            if a[j]>a[j+1]{
                temp = a[j]
                a[j] = a[j+1]
            a[j+1] = temp
            
            }
        }
       
    }
    for k in 1...1{
        print(a)
    }
}
bubblesort()

