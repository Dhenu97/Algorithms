import UIKit
import Swift

var str = "Hello, playground"
func selectionsort(){
    var a = [5,6,2,7,9,3]
    var temp = 0
    for i in 0...5-1{
        var min = i
       for j in i+1...5{
            if a[j]<a[min] {
            min = j
            }
        }
        //a.swapAt(a[i], a[min])

        temp = a[i]
        a[i] = a[min]
        a[min] = temp
    }
    for k in 1...1{
        print(a)
    }
}
selectionsort()
