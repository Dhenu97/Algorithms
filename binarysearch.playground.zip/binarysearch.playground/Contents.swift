import Swift
func binarysearch(){
    var a = [2,3,7,9,11]
    let key = 9
    var high = a.count - 1
    let low = 0

    let mi = (high + low) / 2
    while high > low {
        if a[mi] == key{
            print("value found")
            break
        }
        else if a[mi] < key {
         var low = a[mi] + 1
            
        }
            
        else {
            high = a[mi] - 1
            print(high)
        }
        
    }
    print(a[mi])
}
binarysearch()


//

