import Swift
func insertionsort()
{
    var p = 0
    //var i:Int
    //var j:Int
    var _:Int
    var a = [5,6,2,4,6]
    for i in 1...5-1 {
        //storing i value in another varible to overcome confussion
        var j = i
        p = a[i]
        //if the condition is true then it enters in
        while j>0 && a[j-1]>p {
            //comparing the index values a[0] & a[i]
            a[j] = a[j-1]
            j = j-1
        }
        // p is atemparary variable which points to index value a[1] and compare with index a[0] ie..j
        a[j] = p
    }
    for _ in 1...1 {
       print(p)
    }
    
    
}
insertionsort()

